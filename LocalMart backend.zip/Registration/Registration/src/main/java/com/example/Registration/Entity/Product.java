package com.example.Registration.Entity;

import com.example.Registration.Entity.ProductSubCategory;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "productTable")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "pid")
    private long id;
    @Column(name = "product_name")
    private String productName;
    @Column(name = "product_price")
    private double productPrice;
    @Column(name = "product_desc")
    private String productDescription;
    @Column(name = "product_qty")
    private int productQuantity;


// for bi directional
//@ManyToOne(fetch = FetchType.LAZY)
//@JoinColumn(name = "fk_subcat_id", referencedColumnName = "subcat_id")
//@JsonIgnoreProperties("product")
//private ProductSubCategory productSubCategory;



    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

//    public ProductSubCategory getProductSubCategory() {
//        return productSubCategory;
//    }
//
//    public void setProductSubCategory(ProductSubCategory productSubCategory) {
//        this.productSubCategory = productSubCategory;
//    }

    public Product() {
    }

    public Product( String productName, double productPrice, String productDescription, int productQuantity, ProductSubCategory productSubCategory) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productDescription = productDescription;
        this.productQuantity = productQuantity;
//        this.productSubCategory = productSubCategory;
    }

    public void setSubcategoryId(Long subcategoryId) {
    }


}
