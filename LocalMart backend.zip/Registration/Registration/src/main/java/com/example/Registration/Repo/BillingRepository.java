package com.example.Registration.Repo;

import com.example.Registration.Entity.Billing;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface BillingRepository extends JpaRepository<Billing, Long> {
    List<Billing> findAllByBillingDate(Date billingDate);

    List<Billing> findAllByProductId(Long productId);

    List<Billing> findAllByStatus(String status);
}
