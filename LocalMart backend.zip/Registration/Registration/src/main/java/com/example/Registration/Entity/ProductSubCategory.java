package com.example.Registration.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.List;


@Entity
@Table(name = "subCategoryTable")
public class ProductSubCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="subcat_id")
    private long id;
    @Column(name = "subcategory_name")
    private String subCategoryName;



//    //for bidirectional mapping
//@ManyToOne
//@JoinColumn(name = "fk_cat_id", referencedColumnName = "cat_id")
//@JsonIgnoreProperties("productSubCategories")
//private ProductCategory productCategory;

//
////for mapping to product
//@OneToMany(mappedBy = "productSubCategory", cascade = CascadeType.ALL)
//@JsonIgnoreProperties("productSubCategory")
//private List<Product> product;







// from video
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_subcat_id")
    private List<Product> product;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSubCategoryName() {
        return subCategoryName;
    }

    public void setSubCategoryName(String subCategoryName) {
        this.subCategoryName = subCategoryName;
    }

    public List<Product> getProduct() {
        return product;
    }

    public void setProduct(List<Product> product) {
        this.product = product;
    }

//    public ProductCategory getProductCategory() {
//        return productCategory;
//    }
//
//    public void setProductCategory(ProductCategory productCategory) {
//        this.productCategory = productCategory;
//    }

    public ProductSubCategory() {
    }

    public ProductSubCategory(String subCategoryName, ProductCategory productCategory, List<Product> product) {
        this.subCategoryName = subCategoryName;
//        this.productCategory = productCategory;
        this.product = product;
    }


}