package com.example.Registration.Service.impl;

import com.example.Registration.Entity.Billing;
import com.example.Registration.Repo.BillingRepository;
import com.example.Registration.Service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class BillingServiceImpl implements BillingService {

    @Autowired
    private BillingRepository billingRepository;

    @Override
    public List<Billing> getAllBillings() {
        return billingRepository.findAll();
    }

    @Override
    public Billing getBillingById(Long id) {
        return billingRepository.findById(id).orElse(null);
    }

    @Override
    public Billing createBilling(Billing billing) {
        return billingRepository.save(billing);
    }

    @Override
    public Billing updateBilling(Long id, Billing billing) {
        if (billingRepository.existsById(id)) {
            billing.setBillingId(id);
            return billingRepository.save(billing);
        }
        return null;
    }

    @Override
    public void deleteBilling(Long id) {
        billingRepository.deleteById(id);
    }
    @Override
    public List<Billing> getBillingsByBillingDate(Date billingDate) {
        return billingRepository.findAllByBillingDate(billingDate);
    }

    @Override
    public List<Billing> getBillingsByProductId(Long productId) {
        return billingRepository.findAllByProductId(productId);
    }

    @Override
    public List<Billing> getBillingsByStatus(String status) {
        return billingRepository.findAllByStatus(status);
    }
}



