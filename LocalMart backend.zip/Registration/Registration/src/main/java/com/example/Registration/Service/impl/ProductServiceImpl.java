package com.example.Registration.Service.impl;

import com.example.Registration.Entity.Product;
import com.example.Registration.Repo.ProductRepository;
import com.example.Registration.Service.ProductService;
import com.example.Registration.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product saveProduct(Product product, Long subcategoryId, Long categoryId) {
        // Implement logic to associate product with subcategory and category
        // Example:
        // product.setSubcategoryId(subcategoryId);
        // product.setCategoryId(categoryId);

        return productRepository.save(product);
    }
//    @Override
//    public Product saveProduct(Product product) {
//        return productRepository.save(product);
//    }


    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product updateProduct(Product p, long id) throws RuntimeException {
        Product prod = productRepository.findById(id).get();
        if(prod.getId()!=0) {
            prod.setProductDescription(p.getProductDescription());
            prod.setProductName(p.getProductName());
            prod.setProductPrice(p.getProductPrice());
            prod.setProductQuantity(p.getProductQuantity());

        }
        else
        {
            throw new RuntimeException("Entered product id:"+id+" Not found");
        }
        productRepository.save(prod);
        return prod;
    }

    @Override
    public Product getProductById(Long id) throws ResourceNotFoundException {
        Optional<Product> product = productRepository.findById(id);
        if (product.isPresent()) {
            return product.get();
        } else {
            throw new RuntimeException("Entered id:" + id + "Not found in repositories");
        }
    }

    @Override
    public void deleteProduct (Long id){
        productRepository.deleteById(id);
    }

}

