package com.example.Registration.Repo;


import com.example.Registration.Entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product,Long> {
//    List<Product> findProductsByCategory(String Productcategory);
//    @Query("SELECT pr FROM Product pr WHERE pr.productCategory.name=:prodCategory")
//        List<Product> findProductsByCategory(String Prodcategory);

    @Query(value = "SELECT p FROM Product p where productCategory=:value")
    public List<Product> findProductsByCategory(@Param("value")String productCat);
    @Query(value = "SELECT p FROM Product p where productPrice=:price")
    public List<Product> findProductsByPrice(@Param("price")int productPrices);
    @Query(value = "SELECT p FROM Product p where productName=:name")
    public List<Product> findProductsByName(@Param("name")String productNames);

    @Query(value = "SELECT p FROM Product p where productQuantity=:quantity")
    public List<Product> findProductsByQuantity(@Param("quantity")String productQty);
}

