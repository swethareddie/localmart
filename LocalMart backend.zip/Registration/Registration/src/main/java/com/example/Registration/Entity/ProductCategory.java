package com.example.Registration.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.List;


@Entity
@Table(name = "categoryTable")
public class ProductCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cat_id")
    private Long id;
    @Column(name="category_name")
    private String categoryName;

  //first code
//    @OneToMany(mappedBy = "productCategory", cascade = CascadeType.ALL)
//    @JsonIgnoreProperties("productCategory")
//    private List<ProductSubCategory> productSubCategories;

    //from video
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_cat_id")
    private List<ProductSubCategory> productSubCategories;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public List<ProductSubCategory> getProductSubCategories() {
        return productSubCategories;
    }

    public void setProductSubCategories(List<ProductSubCategory> productSubCategories) {
        this.productSubCategories = productSubCategories;
    }

    public ProductCategory() {
    }

    public ProductCategory( String categoryName, List<ProductSubCategory> productSubCategories) {
        this.categoryName = categoryName;
        this.productSubCategories = productSubCategories;
    }
}