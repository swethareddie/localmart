package com.example.Registration.Controller;

import com.example.Registration.Entity.Billing;
import com.example.Registration.Service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/localmart/bills")
public class BillingController {

    @Autowired
    private BillingService billingService; // Make sure BillingService is defined and annotated with @Service

    @GetMapping
    public ResponseEntity<List<Billing>> getAllBillings() {
        return ResponseEntity.ok(billingService.getAllBillings());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Billing> getBillingById(@PathVariable Long id) {
        Billing billing = billingService.getBillingById(id);
        if (billing != null) {
            return ResponseEntity.ok(billing);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Billing> createBilling(@RequestBody Billing billing) {
        Billing createdBilling = billingService.createBilling(billing);
        return ResponseEntity.ok(createdBilling);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Billing> updateBilling(@PathVariable Long id, @RequestBody Billing billing) {
        Billing updatedBilling = billingService.updateBilling(id, billing);
        if (updatedBilling != null) {
            return ResponseEntity.ok(updatedBilling);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBilling(@PathVariable Long id) {
        billingService.deleteBilling(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/by-date")
    public ResponseEntity<List<Billing>> getBillingsByBillingDate(@RequestParam Date billingDate) {
        List<Billing> billings = billingService.getBillingsByBillingDate(billingDate);
        return ResponseEntity.ok(billings);
    }

    @GetMapping("/by-product")
    public ResponseEntity<List<Billing>> getBillingsByProductId(@RequestParam Long productId) {
        List<Billing> billings = billingService.getBillingsByProductId(productId);
        return ResponseEntity.ok(billings);
    }

    @GetMapping("/by-status")
    public ResponseEntity<List<Billing>> getBillingsByStatus(@RequestParam String status) {
        List<Billing> billings = billingService.getBillingsByStatus(status);
        return ResponseEntity.ok(billings);
    }
}

