package com.example.Registration.Controller;

import com.example.Registration.Dto.UserDto;
import com.example.Registration.Dto.LoginDto;
import com.example.Registration.Entity.Product;
import com.example.Registration.Entity.User;
import com.example.Registration.Service.impl.UserImpl;
import com.example.Registration.response.LoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/localmart/users")
public class UserController {
    @Autowired
    private UserImpl userService;

    @PostMapping(path = "/register")
    public String saveUser(@RequestBody UserDto userDto) {
        String id = userService.addUser(userDto);
        return id;
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);
        if (!user.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID: " + id);
        }
        return ResponseEntity.ok(user.get());
    }

    // Update REST API
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
        try {
            User updatedUser = userService.updateUser(id, user);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete REST API
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return new ResponseEntity<String>("Deleted", HttpStatus.OK);
    }

    @PostMapping(path = "/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginDto loginDto) {
        String defaultAdminEmail = "admin@example.com";
        String defaultAdminPassword = "admin123";

        if (loginDto.getEmail().equals(defaultAdminEmail) && loginDto.getPassword().equals(defaultAdminPassword)) {
            // Admin login successful
            LoginResponse adminLoginResponse = new LoginResponse("Admin login successful", true);
            return ResponseEntity.ok(adminLoginResponse);
        } else {
            // Regular user login logic
            Optional<User> user = userService.getUserByEmailAndPassword(loginDto.getEmail(), loginDto.getPassword());
            if (user.isPresent()) {
                // User login successful
                LoginResponse userLoginResponse = new LoginResponse("User login successful", true);
                return ResponseEntity.ok(userLoginResponse);
            } else {
                // Invalid credentials
                LoginResponse invalidLoginResponse = new LoginResponse("Invalid email or password", false);
                return ResponseEntity.ok(invalidLoginResponse);
            }
        }
    }

}

