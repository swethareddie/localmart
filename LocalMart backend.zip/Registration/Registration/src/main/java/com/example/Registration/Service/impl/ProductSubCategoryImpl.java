package com.example.Registration.Service.impl;


import com.example.Registration.Entity.ProductSubCategory;
import com.example.Registration.Repo.ProductSubCategoryRepository;
import com.example.Registration.Service.ProductSubCategoryService;
import com.example.Registration.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ProductSubCategoryImpl implements ProductSubCategoryService
{
    @Autowired
    private ProductSubCategoryRepository productSubCategoryRepository;
    @Override
    public List<ProductSubCategory> getAllSubCategories() {
        return productSubCategoryRepository.findAll();
    }

    @Override
    public ProductSubCategory getSubCategoryById(Long id) {
        return productSubCategoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SubCategory not found with id: " + id));
    }

    @Override
    public ProductSubCategory saveSubCategory(ProductSubCategory subCategory) {
        return productSubCategoryRepository.save(subCategory);
    }

    @Override
    public ProductSubCategory updateSubCategory(ProductSubCategory psc, long id) throws RuntimeException {
        ProductSubCategory subcat = productSubCategoryRepository.findById(id).get();
        if(subcat.getId()!=0) {

            subcat.setSubCategoryName(psc.getSubCategoryName());
            subcat.setProduct(psc.getProduct());
        }
        else
        {
            throw new RuntimeException("Entered product id:"+id+" Not found");
        }
        productSubCategoryRepository.save(subcat);
        return subcat;
    }

    @Override
    public void deleteSubCategory(Long id) {
        productSubCategoryRepository.deleteById(id);
    }
}