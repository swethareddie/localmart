package com.example.Registration.Service;


import com.example.Registration.Entity.Product;

import java.util.List;


public interface ProductService {
    public Product saveProduct(Product product, Long subcategoryId, Long categoryId);
//    public Product saveProduct(Product product);

    public List<Product> getAllProducts() ;
    public Product updateProduct(Product p,long id) throws RuntimeException;
    public Product getProductById(Long id) ;

    public void deleteProduct(Long id) ;

}

