package com.example.Registration.Service.impl;
import com.example.Registration.Dto.UserDto;
import com.example.Registration.Dto.LoginDto;
import com.example.Registration.Entity.User;
import com.example.Registration.Repo.UserRepo;
import com.example.Registration.Service.UserService;
import com.example.Registration.response.LoginResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class UserImpl implements UserService {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Override
    public String addUser(UserDto userDto) {
        User user = new User(
               userDto.getId(),
                userDto.getUsername(),
                this.passwordEncoder.encode(userDto.getPassword()),
                userDto.getGender(),
                userDto.getEmail(),


                userDto.getUserType(),
                userDto.getPhoneNumber(),
                userDto.getAddress()


        );
        userRepo.save(user);
        return user.getUsername();
    }

  UserDto userDto;

    @Override
    public List<User> getAllUsers() {

        return userRepo.findAll();
    }
    @Override
    public User findUserById(long id) throws RuntimeException {
        Optional<User> user = userRepo.findById(id);
        if (user.isPresent()) {
            return user.get();
        } else {
            throw new RuntimeException("User not found with id: " + id);
        }
    }
//    @Override
//    public LoginResponse loginUser(LoginDto loginDto) {
//        User user = userRepo.findByEmail(loginDto.getEmail());
//        if (user != null) {
//            String encodedPassword = user.getPassword();
//            boolean isPasswordCorrect = passwordEncoder.matches(loginDto.getPassword(), encodedPassword);
//            if (isPasswordCorrect) {
//                // Password matches, login successful
//                return new LoginResponse("Login successful", true);
//            } else {
//                // Password doesn't match, return custom message
//                return new LoginResponse("Incorrect email or password", false);
//            }
//        } else {
//            // User not found with the provided email
//            return new LoginResponse("User with the provided email does not exist", false);
//        }
//    }

    @Override
    public Optional<User> getUserByEmailAndPassword(String email, String password) {
        return userRepo.findOneByEmailAndPassword(email, password);
    }

    @Override
    public User findUserByUserName(User user, long id) throws RuntimeException {
        Optional<User> existingUser = userRepo.findById(id);
        if (existingUser.isPresent()) {
            return existingUser.get();
        } else {
            throw new RuntimeException("User not found with id: " + id);
        }
    }

    @Override
    public User findUserByUserType(Long id, User user) throws RuntimeException {
        return null;
    }


    @Override
    public User updateUser(Long id, User user) {
        User user1=userRepo.findById(id).orElseThrow(()->new RuntimeException("user not found with id:"+id));
        user1.setEmail(user.getEmail());
        user1.setPassword(user.getPassword());
        return userRepo.save(user1);
    }

    @Override
    public void deleteUser(long id) {
        userRepo.deleteById(id);
    }

    public Optional<User> getUserById(Long id) {
        return userRepo.findById(id);
    }
    public Optional<User> getUserByUserType(String userType) {
        // Perform database query or logic to fetch users by userType
        // Return the list of users
        return userRepo.findByUserType(userType);
    }


    public Optional<User> getUserByUsername(String username) {
        return userRepo.findByUsername(username);
    }
    @Override
    public LoginResponse loginUser(LoginDto loginDto) {
        String defaultAdminEmail = "admin@example.com";
        String defaultAdminPassword = "admin123";

        // Check if the login attempt is for admin
        if (loginDto.getEmail().equals(defaultAdminEmail) && loginDto.getPassword().equals(defaultAdminPassword)) {
            // Admin login successful
            LoginResponse adminLoginResponse = new LoginResponse("Admin login successful", true);
            return adminLoginResponse;
        } else {
            // Regular user login
            Optional<User> user = Optional.ofNullable(userRepo.findByEmail(loginDto.getEmail()));
            if (user.isPresent()) {
                // User found, check password
                if (passwordEncoder.matches(loginDto.getPassword(), user.get().getPassword())) {
                    // Password correct, user login successful
                    LoginResponse userLoginResponse = new LoginResponse("User login successful", true);
                    return userLoginResponse;
                } else {
                    // Password incorrect
                    LoginResponse invalidPasswordResponse = new LoginResponse("Invalid password", false);
                    return invalidPasswordResponse;
                }
            } else {
                // User not found with provided email
                LoginResponse userNotFoundResponse = new LoginResponse("User not found", false);
                return userNotFoundResponse;
            }
        }
    }



}

//    @Override
//    public List<User> findUserByUserName(String userName) {
//        return userRepo.findByUsername(userName);
//    }
//
//    @Override
//    public List<User> getAllLogin() {
//        return userRepo.findAll();
//    }
//
//    @Override
//    public List<User> findByLogin(String userLogin) {
//        return null;
//    }



