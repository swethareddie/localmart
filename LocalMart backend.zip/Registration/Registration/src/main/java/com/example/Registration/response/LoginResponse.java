package com.example.Registration.response;

public class LoginResponse {
    private String message;
    private Boolean success;

    // Constructor
    public LoginResponse(String message, Boolean success) {
        this.message = message;
        this.success = success;
    }

    // Getters and setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }
}

