package com.example.Registration.Service;



import com.example.Registration.Entity.ProductSubCategory;

import java.util.List;

public interface ProductSubCategoryService {
    public List<ProductSubCategory> getAllSubCategories();
    public ProductSubCategory getSubCategoryById(Long id);
    public ProductSubCategory saveSubCategory(ProductSubCategory subCategory);
    public ProductSubCategory updateSubCategory(ProductSubCategory psc, long id) throws RuntimeException;
    public void deleteSubCategory(Long id);

}