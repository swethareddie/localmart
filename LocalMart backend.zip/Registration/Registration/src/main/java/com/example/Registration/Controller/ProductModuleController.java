package com.example.Registration.Controller;





import com.example.Registration.Entity.Product;
import com.example.Registration.Entity.ProductCategory;
import com.example.Registration.Entity.ProductSubCategory;
import com.example.Registration.Service.ProductCategoryService;
import com.example.Registration.Service.ProductService;
import com.example.Registration.Service.ProductSubCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/mart")
public class ProductModuleController {

    @Autowired
    private ProductCategoryService productCategoryService;

    @Autowired
    private ProductSubCategoryService productSubCategoryService;

    @Autowired
    private ProductService productService;

    // ProductCategory mappings

    @GetMapping("/category")
    public ResponseEntity<List<ProductCategory>> getAllProductCategories() {
        List<ProductCategory> productCategories = productCategoryService.getAllCategories();
        return new ResponseEntity<>(productCategories, HttpStatus.OK);
    }

    @GetMapping("/category/{id}")
    public ResponseEntity<ProductCategory> getCategoryById(@PathVariable Long id) {
        ProductCategory category = productCategoryService.getCategoryById(id);
        return ResponseEntity.ok().body(category);
    }

    @PostMapping("/category")
    public ResponseEntity<ProductCategory> createCategory(@RequestBody ProductCategory productCategory) {
        ProductCategory createdCategory = productCategoryService.saveProductCategory(productCategory);
        return new ResponseEntity<>(createdCategory, HttpStatus.CREATED);
    }

    @PutMapping("/category/{id}")
    public ResponseEntity<ProductCategory> updateCategory(@RequestBody ProductCategory pc, @PathVariable("id") long productCategoryId) throws RuntimeException{
        return new ResponseEntity<ProductCategory>(productCategoryService.updateCategory(pc, productCategoryId), HttpStatus.OK);
    }

    @DeleteMapping("/category/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable Long id) {
        productCategoryService.deleteCategory(id);
        return ResponseEntity.ok().build();
    }

    // ProductSubCategory mappings

    @GetMapping("/subcategory")
    public ResponseEntity<List<ProductSubCategory>> getAllSubCategories() {
        List<ProductSubCategory> productSubCategories = productSubCategoryService.getAllSubCategories();
        return new ResponseEntity<>(productSubCategories, HttpStatus.OK);
    }

    @GetMapping("/subcategory/{id}")
    public ResponseEntity<ProductSubCategory> getSubCategoryById(@PathVariable Long id) {
        ProductSubCategory subCategory = productSubCategoryService.getSubCategoryById(id);
        return ResponseEntity.ok().body(subCategory);
    }

    @PostMapping("/subcategory")
    public ResponseEntity<ProductSubCategory> createSubCategory(@RequestBody ProductSubCategory subCategory) {
        ProductSubCategory createdSubCategory = productSubCategoryService.saveSubCategory(subCategory);
        return new ResponseEntity<>(createdSubCategory, HttpStatus.CREATED);
    }

    //from chat gpt for bidirectional
//    @PostMapping("/subcategory/{categoryId}/create")
//    public ResponseEntity<ProductSubCategory> createSubCategoryWithCategoryId(@RequestBody ProductSubCategory subCategory, @PathVariable Long categoryId) {
//        ProductCategory category = productCategoryService.getCategoryById(categoryId);
//        if (category == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        subCategory.setProductCategory(category);
//        ProductSubCategory createdSubCategory = productSubCategoryService.saveSubCategory(subCategory);
//        return new ResponseEntity<>(createdSubCategory, HttpStatus.CREATED);
//    }


    @PutMapping("/subcategory/{id}")
    public ResponseEntity<ProductSubCategory> updateSubCategory(@RequestBody ProductSubCategory psc, @PathVariable("id") long productSubCategoryId) throws RuntimeException{
        return new ResponseEntity<ProductSubCategory>(productSubCategoryService.updateSubCategory(psc, productSubCategoryId), HttpStatus.OK);
    }

    @DeleteMapping("/subcategory/{id}")
    public ResponseEntity<?> deleteSubCategory(@PathVariable Long id) {
        productSubCategoryService.deleteSubCategory(id);
        return ResponseEntity.ok().build();
    }

    // Product mappings

    @GetMapping("/product")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @PostMapping("/product/{subcategoryId}/{categoryId}/save")
    public ResponseEntity<Product> createProduct(@RequestBody Product product, @PathVariable Long subcategoryId, @PathVariable Long categoryId) {
        product.setSubcategoryId(subcategoryId);
        Product createdProduct = productService.saveProduct(product, subcategoryId, categoryId);
        return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
    }

    @PutMapping("/product/{id}")
    public ResponseEntity<Product> updateProduct(@RequestBody Product p, @PathVariable("id") long productId) throws RuntimeException{
        return new ResponseEntity<Product>(productService.updateProduct(p, productId), HttpStatus.OK);
    }

    @DeleteMapping("/product/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return ResponseEntity.ok().build();
    }


}