package com.example.Registration.Service;



import com.example.Registration.Entity.ProductCategory;

import java.util.List;

public interface ProductCategoryService {
    //from chatgpt
    ProductCategory saveProductCategory(ProductCategory productCategory);

    public List<ProductCategory> getAllCategories();
    public ProductCategory getCategoryById(Long id);
//    public ProductCategory saveCategory(ProductCategory categoryName);
    public ProductCategory updateCategory(ProductCategory pc, long id) throws RuntimeException;
    public void deleteCategory(Long id);
}