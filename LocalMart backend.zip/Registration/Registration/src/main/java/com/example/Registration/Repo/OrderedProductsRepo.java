package com.example.Registration.Repo;

import com.example.Registration.Entity.OrderedProducts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderedProductsRepo extends JpaRepository<OrderedProducts, Long> {
}
