package com.example.Registration.Service.impl;

import com.example.Registration.Entity.ProductCategory;
import com.example.Registration.Repo.ProductCategoryRepository;
import com.example.Registration.Service.ProductCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {
    @Autowired
    private ProductCategoryRepository productCategoryRepository;

    @Override
    public ProductCategory saveProductCategory(ProductCategory productCategory) {
        return productCategoryRepository.save(productCategory);
    }

    @Override
    public List<ProductCategory> getAllCategories() {
        return productCategoryRepository.findAll();
    }

//    @Override
//    public ProductCategory getCategoryById(Long id) {
//        return productCategoryRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + id));
//    }
//

    // from sir text
    @Override
    public ProductCategory getCategoryById(Long id) {
        return productCategoryRepository.findById(id).get();
    }
    @Override
    public ProductCategory updateCategory(ProductCategory pc, long id) throws RuntimeException {
        ProductCategory cat = productCategoryRepository.findById(id).get();
        if(cat.getId()!=0) {

            cat.setCategoryName(pc.getCategoryName());
           cat.setProductSubCategories(pc.getProductSubCategories());
        }
        else
        {
            throw new RuntimeException("Entered product id:"+id+" Not found");
        }
        productCategoryRepository.save(cat);
        return cat;
    }


    @Override
    public void deleteCategory(Long id) {
        productCategoryRepository.deleteById(id);
    }
}