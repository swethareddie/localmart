package com.example.Registration.Service;

import com.example.Registration.Entity.Billing;

import java.util.Date;
import java.util.List;

public interface BillingService {
    List<Billing> getAllBillings();
    Billing getBillingById(Long id);
    Billing createBilling(Billing billing);
    Billing updateBilling(Long id, Billing billing);
    void deleteBilling(Long id);
    List<Billing> getBillingsByBillingDate(Date billingDate);
    List<Billing> getBillingsByProductId(Long productId);
    List<Billing> getBillingsByStatus(String status);
}
