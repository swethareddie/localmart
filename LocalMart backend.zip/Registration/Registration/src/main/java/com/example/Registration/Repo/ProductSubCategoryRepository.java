package com.example.Registration.Repo;


import com.example.Registration.Entity.ProductSubCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductSubCategoryRepository extends JpaRepository<ProductSubCategory,Long> {
}