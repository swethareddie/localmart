package com.example.Registration.Service;
import com.example.Registration.Dto.UserDto;
import com.example.Registration.Dto.LoginDto;
import com.example.Registration.Entity.User;
import com.example.Registration.response.LoginResponse;

import java.util.List;
import java.util.Optional;


public interface UserService {
    String addUser(UserDto userDto);

    List<User> getAllUsers();

    User findUserById(long id) throws RuntimeException;


    User findUserByUserName(User user, long id) throws RuntimeException;

    User findUserByUserType(Long id, User user) throws RuntimeException;

    User updateUser(Long id, User user);

    void deleteUser(long id);

    LoginResponse loginUser(LoginDto loginDto);

    Optional<User> getUserByEmailAndPassword(String email, String password);

//    List<User> findUserByUserName(String userName);
}
